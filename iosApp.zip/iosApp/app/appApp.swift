//
//  appApp.swift
//  app
//
//  Created by Nekbakht Zabirov on 16.09.2023.
//

import SwiftUI
import shared

@main
struct appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
